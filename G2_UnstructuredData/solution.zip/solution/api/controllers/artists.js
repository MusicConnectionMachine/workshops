'use strict';

// load our fake database
let storage = require('../helpers/storage.js');

// export all our functions so swagger can actually call them
module.exports = {
    getArtists: getArtists,
    createArtist: createArtist,
    getArtistById: getArtistById,
    updateArtist: updateArtist,
    deleteArtist: deleteArtist
};

/** TASK 2 */
function getArtists(req, res) {
    // read all artists from fake database
    let artists = storage.readAllArtists();
    res.status(200).json(artists);
}

/** TASK 4 */
function createArtist(req, res) {
    // get POST request body content
    let artist = req.swagger.params.artist_data.value;

    // create artist
    let result = storage.createArtist(artist.name, artist.birthdate, artist.deathdate);
    res.status(200).json(result);
}

/** TASK 3 */
function getArtistById(req, res) {
    // get in path parameter 'id'
    let artistId = req.swagger.params.id.value;

    // try to read artist
    let artist = storage.readArtist(artistId);

    // check if we actually have that artist in our fake database
    if (artist !== null) {
        res.status(200).json(artist);
    } else {
        res.status(404).json("Couldn't find that artist! Sorry :/");
    }
}

/** TASK 4 */
function updateArtist(req, res) {
    // get in path parameter 'id'
    let artistId = req.swagger.params.id.value;

    // get PUT request body
    let artist = req.swagger.params.artist_data.value;

    // try to update artist
    let result = storage.updateArtist(artistId, artist.name, artist.birthdate, artist.deathdate);

    // check if we actually have that artist in our fake database
    if (result !== null) {
        res.status(200).json(result);
    } else {
        res.status(404).json("Couldn't find that artist! Sorry :/");
    }
}

/** TASK 4 */
function deleteArtist(req, res) {
    // get in path parameter 'id'
    let artistId = req.swagger.params.id.value;

    // try to delete artist
    let result = storage.deleteArtist(artistId);

    // check if we actually have that artist in our fake database
    if (result !== null) {
        // only empty JSON is allowed here by our definition!
        res.status(200).json();
    } else {
        res.status(404).json("Couldn't find that artist! Sorry :/");
    }
}

