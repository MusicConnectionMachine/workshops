'use strict';

// load our fake database
let storage = require('../helpers/storage.js');

// export all our functions so swagger can actually call them
module.exports = {
    getPieces: getPieces,
    createPiece: createPiece,
    getPieceById: getPieceById,
    updatePiece: updatePiece,
    deletePiece: deletePiece
};

function getPieces(req, res) {
    // get in path parameter 'id'
    let artistId = req.swagger.params.artist_id.value;

    // try to read artist
    let artist = storage.readArtist(artistId);

    // check if we actually have that artist in our fake database
    if (artist !== null) {
        res.status(200).json(artist.pieces);
    } else {
        res.status(404).json("Couldn't find that artist! Sorry :/");
    }
}

function createPiece(req, res) {
    res.status(501).json('Not implemented!');
}

function getPieceById(req, res) {
    res.status(501).json('Not implemented!');
}

function updatePiece(req, res) {
    res.status(501).json('Not implemented!');
}

function deletePiece(req, res) {
    res.status(501).json('Not implemented!');
}